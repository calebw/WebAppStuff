﻿namespace MarkupProject
{
    partial class MarkupProjectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAverage = new System.Windows.Forms.Button();
            this.btnRange = new System.Windows.Forms.Button();
            this.btnHighLow = new System.Windows.Forms.Button();
            this.btnRetrieve = new System.Windows.Forms.Button();
            this.cboScoreRuns = new System.Windows.Forms.ComboBox();
            this.dateEnd = new System.Windows.Forms.DateTimePicker();
            this.dateBegin = new System.Windows.Forms.DateTimePicker();
            this.btnScoreFile = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "html files (*.html)|*.html";
            this.openFileDialog1.FilterIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(560, 328);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAverage);
            this.groupBox1.Controls.Add(this.btnRange);
            this.groupBox1.Controls.Add(this.btnHighLow);
            this.groupBox1.Controls.Add(this.btnRetrieve);
            this.groupBox1.Controls.Add(this.cboScoreRuns);
            this.groupBox1.Controls.Add(this.dateEnd);
            this.groupBox1.Controls.Add(this.dateBegin);
            this.groupBox1.Controls.Add(this.btnScoreFile);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(560, 81);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // btnAverage
            // 
            this.btnAverage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAverage.Location = new System.Drawing.Point(488, 22);
            this.btnAverage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAverage.Name = "btnAverage";
            this.btnAverage.Size = new System.Drawing.Size(56, 43);
            this.btnAverage.TabIndex = 7;
            this.btnAverage.Text = "Retrieve Average";
            this.btnAverage.UseVisualStyleBackColor = true;
            // 
            // btnRange
            // 
            this.btnRange.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRange.Location = new System.Drawing.Point(406, 23);
            this.btnRange.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRange.Name = "btnRange";
            this.btnRange.Size = new System.Drawing.Size(56, 42);
            this.btnRange.TabIndex = 6;
            this.btnRange.Text = "Retrieve Range";
            this.btnRange.UseVisualStyleBackColor = true;
            // 
            // btnHighLow
            // 
            this.btnHighLow.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnHighLow.Location = new System.Drawing.Point(200, 46);
            this.btnHighLow.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnHighLow.Name = "btnHighLow";
            this.btnHighLow.Size = new System.Drawing.Size(85, 19);
            this.btnHighLow.TabIndex = 5;
            this.btnHighLow.Text = "High/Low";
            this.btnHighLow.UseVisualStyleBackColor = true;
            // 
            // btnRetrieve
            // 
            this.btnRetrieve.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRetrieve.Location = new System.Drawing.Point(200, 22);
            this.btnRetrieve.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRetrieve.Name = "btnRetrieve";
            this.btnRetrieve.Size = new System.Drawing.Size(85, 19);
            this.btnRetrieve.TabIndex = 4;
            this.btnRetrieve.Text = "Retrieve Score";
            this.btnRetrieve.UseVisualStyleBackColor = true;
            // 
            // cboScoreRuns
            // 
            this.cboScoreRuns.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboScoreRuns.FormattingEnabled = true;
            this.cboScoreRuns.Location = new System.Drawing.Point(104, 32);
            this.cboScoreRuns.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboScoreRuns.Name = "cboScoreRuns";
            this.cboScoreRuns.Size = new System.Drawing.Size(92, 21);
            this.cboScoreRuns.TabIndex = 3;
            // 
            // dateEnd
            // 
            this.dateEnd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateEnd.Location = new System.Drawing.Point(311, 46);
            this.dateEnd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateEnd.Name = "dateEnd";
            this.dateEnd.Size = new System.Drawing.Size(92, 20);
            this.dateEnd.TabIndex = 2;
            // 
            // dateBegin
            // 
            this.dateBegin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateBegin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateBegin.Location = new System.Drawing.Point(311, 23);
            this.dateBegin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateBegin.Name = "dateBegin";
            this.dateBegin.Size = new System.Drawing.Size(92, 20);
            this.dateBegin.TabIndex = 1;
            // 
            // btnScoreFile
            // 
            this.btnScoreFile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnScoreFile.Location = new System.Drawing.Point(19, 33);
            this.btnScoreFile.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnScoreFile.Name = "btnScoreFile";
            this.btnScoreFile.Size = new System.Drawing.Size(64, 19);
            this.btnScoreFile.TabIndex = 0;
            this.btnScoreFile.Text = "Score File";
            this.btnScoreFile.UseVisualStyleBackColor = true;
            this.btnScoreFile.Click += new System.EventHandler(this.btnScoreFile_Click);
            // 
            // MarkupProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 328);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "MarkupProject";
            this.Text = "MarkupProject";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnHighLow;
        private System.Windows.Forms.Button btnRetrieve;
        private System.Windows.Forms.ComboBox cboScoreRuns;
        private System.Windows.Forms.DateTimePicker dateEnd;
        private System.Windows.Forms.DateTimePicker dateBegin;
        private System.Windows.Forms.Button btnScoreFile;
        private System.Windows.Forms.Button btnAverage;
        private System.Windows.Forms.Button btnRange;
    }
}

