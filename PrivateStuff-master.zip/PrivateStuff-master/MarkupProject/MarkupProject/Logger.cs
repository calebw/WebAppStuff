﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarkupProject
{
    internal static class Logger
    {
        internal static void ShowErrMsg(string body, string caption)
        {
            MessageBox.Show(body, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
