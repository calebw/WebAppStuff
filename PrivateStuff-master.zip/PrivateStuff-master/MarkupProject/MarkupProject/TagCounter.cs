﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MarkupProject
{
    class TagCounter
    {
        private string filepath;
        private static string pattern;
        private static Dictionary<string, int> pointLookup;

        /// <summary>
        /// Dynamically creates PointLookup and RegEx Pattern
        /// </summary>
        static TagCounter()
        {
            pointLookup = new Dictionary<string, int>();
            pattern = @"";
            var tags = Enum.GetNames(typeof(TagPoints));
            var vals = Enum.GetValues(typeof(TagPoints));
            foreach (string tag in tags)
            {
                pattern = string.Concat(pattern, "<", tag, @"[>|\s]|");
                pointLookup.Add(tag, (int)Enum.Parse(typeof(TagPoints), tag));
            }
            pattern = pattern.TrimEnd('|');
        }

        public TagCounter(string file)
        {
            filepath = file;
        }

        /// <summary>
        /// Get point for tag given regex match.
        /// </summary>
        private int GetTagPoint(string match)
        {
            string tag = match.Substring(1, match.Length-2);
            return pointLookup[tag];
        }

        /// <summary>
        /// Calculate Score
        /// </summary>
        public bool Execute(out int score)
        {
            score = 0;
            if (Path.GetExtension(filepath) != ".html") {
                return false;
            }
            try {
                Regex reg = new Regex(pattern, RegexOptions.IgnoreCase);
                foreach (string line in File.ReadLines(filepath))
                {
                    Match m = reg.Match(line);
                    while (m.Success)
                    {
                        score += GetTagPoint(m.Value);
                        m = m.NextMatch();
                    }
                }
                return true;
            }
            catch (Exception) {
                return false;
            }
        }
    }

    /// <summary>
    /// Add/Update this if you want to change the scoring criteria
    /// </summary>
    enum TagPoints {
        div = 3,
        p = 1,
        h1 = 3,
        h2 = 2,
        html = 5,
        body = 5,
        header = 10,
        footer = 10,
        font = -1,
        center = -2,
        big = -2,
        strike = -1,
        tt = -2,
        frameset = -5,
        frame = -5
    }
}
