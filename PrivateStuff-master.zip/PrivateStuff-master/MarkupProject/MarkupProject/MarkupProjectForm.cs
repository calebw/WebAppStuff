﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarkupProject
{
    public partial class MarkupProjectForm : Form
    {
        public MarkupProjectForm()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName;
        }

        private void btnScoreFile_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                TagCounter counter = new TagCounter(openFileDialog1.FileName);
                int score;
                bool success = counter.Execute(out score);
                if (success)
                {
                    try {
                        string fileName = Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
                        string scoreName = fileName.Substring(0, fileName.IndexOf("_"));
                        ScoreUtil.InsertNewScore(fileName, scoreName, score, DateTime.Now);
                    }
                    catch (ArgumentOutOfRangeException) {
                        Logger.ShowErrMsg("Filename has incorrect format.", "Invalid Filename");
                    }
                    catch (Exception)
                    {
                        ;
                    }
                }
                else
                {
                    Logger.ShowErrMsg("There was a problem scoring this file.","Error Scoring");
                }
            }
        }
    }
}
